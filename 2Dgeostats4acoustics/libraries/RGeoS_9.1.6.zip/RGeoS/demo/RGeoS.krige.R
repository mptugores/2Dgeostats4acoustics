# 
# Interactive demonstration of the Variogram / Kriging procedure
#
clean <- function()
{
	if (get.yn("Clean the data set",default="y"))
	{
		liste <- c("ncell","nlag","ndir","ang0","dirvect",
		      	   "rx1","rx2","ext1","ext2","diam","x1","x2","z1",
			   "db.data","db.grid","test.vario","test.model",
			   "test.neigh","clean","finish")
		for (i in 1:length(liste))
		    if (exists(liste[i])) rm(list=liste[i],pos=1)
		if (dev.cur() != 1) dev.off()
	}
}
finish <- function()
{
	clean()
	stop("Demo terminated")
}

#
# Script of the test 
#

# Questions #
x1 <- eval(parse(text=readline(prompt="Vector for the first coordinate = ")))
if (length(x1) <= 0) finish()
x2 <- eval(parse(text=readline(prompt="Vector for the second coordinate = ")))
if (length(x2) <= 0) finish()
z1 <- eval(parse(text=readline(prompt="Vector for the target variable = ")))
if (length(z1) <= 0) finish()
ncell <- get.num("Number of cells for kriging grid",default=50,minimum=1,maximum=100)
nlag  <- get.num("Number of variogram lags",default=10,minimum=2,maximum=100)
ndir  <- get.num("Number of variogram directions",default=4,minimum=1,maximum=4)
ang0  <- get.num("Reference direction",default=0,minimum=0,maximum=180)

# Create the graphic window #
split.screen(c(2,2))

# Creating the Data DB #
rx1  <- extendrange(x1)
rx2  <- extendrange(x2)
db.data <- db.create(x1=x1,x2=x2,z1=z1)
rm(x1,x2,z1)
screen(1)
plot(db.data,title="Data",reset=FALSE)

# Creating the grid DB #
ext1 <- rx1[2] - rx1[1]
ext2 <- rx2[2] - rx2[1]
diam <- sqrt(ext1 * ext1 + ext2 * ext2)
db.grid <- db.create(flag.grid=TRUE,x0=c(rx1[1],rx2[1]),
	   nx=c(ncell,ncell),dx=c(ext1/ncell,ext2/ncell))

# Creating the neighborhood #
test.neigh <- neigh.init(ndim=2,type=0)

# Calculate the experimental variogram and automatic fit #
dirvect <- (seq(1,ndir)-1) * 180 / ndir + ang0

test.vario <- vario.calc(db.data,dirvect=dirvect,lag=diam/(2*nlag),nlag=nlag)
test.model <- model.auto(test.vario,draw=FALSE)
screen(2)
vario.plot(test.vario,tile="Model",reset=FALSE)
model.plot(test.model,vario=test.vario,add=T)

# Perform the Kriging #
db.grid <- kriging(db.data,db.grid,test.model,test.neigh)

# Plot the results #
screen(3)
plot(db.grid,name.image="K.z1.estim",title="Estimation",reset=FALSE)
plot(db.data,pch=21,name.post="z1",bg.in="blue",add=TRUE)

screen(4)
plot(db.grid,name.image="K.z1.stdev",title="St. Deviation",reset=FALSE)
plot(db.data,pch=21,name.post="z1",bg.in="blue",add=TRUE)

finish()
