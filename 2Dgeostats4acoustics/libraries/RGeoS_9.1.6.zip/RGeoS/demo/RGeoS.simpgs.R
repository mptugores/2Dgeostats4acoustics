# 
# This demonstration shows the performance of RGeoS
# for performing categorical simulations within 
# the Truncated PluriGaussian Truncated Model
#
clean <- function()
{
	if (get.yn("Clean the data set",default="y"))
	{
		liste <- c("grid","palperso",
		           "Exdemo_simpgs.db","Exdemo_simpgs.model",
			   "Exdemo_simpgs.neigh",
			   "Exdemo_simpgs_std.rule","Exdemo_simpgs_shift.rule",
			   "Exdemo_simpgs_shadow.rule","nx",
			   "clean")
		for (i in 1:length(liste))
		    if (exists(liste[i])) rm(list=liste[i],pos=1)
		if (dev.cur() != 1) dev.off()
	}
}

# Build the output grid
nx <- 100
grid<-db.create(flag.grid=T,nx=c(nx,nx))

# Build a relevant color scale
palperso<-c("orange","green","black")

# Load various data sets
data(Exdemo_simpgs.db)             # Data Set
data(Exdemo_simpgs.model)   	   # Cubic model
data(Exdemo_simpgs.neigh)   	   # Neighborhood(Unique)
data(Exdemo_simpgs_std.rule)       # Standard Rule (3 facies: S T F 2 F 3 F 1)
data(Exdemo_simpgs_shift.rule)     # Rule with shift
data(Exdemo_simpgs_shadow.rule)    # Rule with shadow

# Create non-stationary proportions
grid<-db.add(grid,p1=(x1/nx))
grid<-db.add(grid,p3=(1-p1)/2)
grid<-db.add(grid,p2=(1-p1-p3))
grid <- db.locate(grid,seq(4,6),loctype="p")

# Close any previous screen #
if (split.screen()[1]) clean.window()
split.screen(c(2,2),erase=TRUE)		
screen(1)		
plot(grid,name.image="p1",zlim=c(0,1),reset=FALSE,title="Proportion #1")
screen(2)		
plot(grid,name.image="p2",zlim=c(0,1),reset=FALSE,title="Proportion #2")
screen(3)		
plot(grid,name.image="p3",zlim=c(0,1),reset=FALSE,title="Proportion #3")
clean.window()

# Page with 4 different PGS realizations
split.screen(c(2,2),erase=TRUE)		

# Standard PGS with two underlying GRFs
screen(1)
plot(simpgs(dbout=grid,model1=Exdemo_simpgs.model,
	model2=Exdemo_simpgs.model,
	neigh=Exdemo_simpgs.neigh,
	seed=12324,flag.stat=T,props=c(0.4,.4,.2),rule=Exdemo_simpgs_std.rule),
	col=palperso,title="PGS with 2 GRFs (Stat)",reset=FALSE)

screen(2)
plot(simpgs(dbout=grid,dbprop=grid,model1=Exdemo_simpgs.model,
	model2=Exdemo_simpgs.model,
	neigh=Exdemo_simpgs.neigh,
	seed=12324,flag.stat=F,rule=Exdemo_simpgs_std.rule),
	col=palperso,title="PGS with 2 GRFs (Non Stat)",reset=FALSE)

# PGS with Shift
screen(3)
plot(simpgs(dbout=grid,model1=Exdemo_simpgs.model,
	neigh=Exdemo_simpgs.neigh,
	flag.stat=T,props=c(.3,.3,.4),
	seed=123245,rule=Exdemo_simpgs_shift.rule),
	col=palperso,title="PGS with Shift (Stat)",reset=FALSE)

screen(4)
plot(simpgs(dbout=grid,dbprop=grid,model1=Exdemo_simpgs.model,
	neigh=Exdemo_simpgs.neigh,
	flag.stat=F,seed=123245,
	rule=Exdemo_simpgs_shift.rule),
	col=palperso,title="PGS with Shift (Non Stat)",reset=FALSE)

clean.window()

# Simulation followed by the threshold
split.screen(c(2,2),erase=TRUE)		
grid <- simtub(dbout=grid,model=Exdemo_simpgs.model,seed=12345,nbsimu=2)

screen(1)
plot(grid,reset=FALSE)

screen(2)
plot(db.rule(grid,rule=Exdemo_simpgs_std.rule,model=Exdemo_simpgs.model,
	radix="Simu.std"),col=palperso,title="Proportion #1",reset=FALSE)

screen(3)
plot(db.rule(grid,rule=Exdemo_simpgs_shift.rule,model=Exdemo_simpgs.model,
	radix="Simu.shift"),col=palperso,title="Proportion #2",reset=FALSE)

screen(4)
plot(db.rule(grid,rule=Exdemo_simpgs_shadow.rule,model=Exdemo_simpgs.model,
	radix="Simu.shadow"),col=palperso,title="Proportion #3",reset=FALSE)
clean.window()

# Conditional PGS with Shadow
split.screen(c(2,2),erase=TRUE)		

screen(1)
plot(simpgs(dbin=Exdemo_simpgs.db,dbout=grid,model1=Exdemo_simpgs.model,
	neigh=Exdemo_simpgs.neigh,flag.stat=T,
	seed=12345,rule=Exdemo_simpgs_shadow.rule,radix="shadow.stat.cond"),
	col=palperso,reset=FALSE)

screen(2)
plot(Exdemo_simpgs.db,bg.in=palperso,fg.in="black",flag.noresize=T,
	add=T,reset=FALSE)

clean()
