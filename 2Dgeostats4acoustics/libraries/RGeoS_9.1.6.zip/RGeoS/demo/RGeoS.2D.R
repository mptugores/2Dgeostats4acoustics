#
# This script is meant to demonstrate the capabilities of RGeoS
# in processing a 2-D data set
#
clean <- function()
{
	if (get.yn("Clean the data set",default="y"))
	{
		liste <- c("data.4dir.vario","data.db","Exdemo_2D_moving.neigh",
		           "data.model","Exdemo_2D_unique.neigh","data.vario",
			   "grid.db","Exdemo_2D_pollution.table","data.anam",
			   "data.g.model","data.g.vario","clean")
		for (i in 1:length(liste))
		    if (exists(liste[i])) rm(list=liste[i],pos=1)
		if (dev.cur() != 1) dev.off()
	}
}

# Load the data and create the corresponding Db
data(Exdemo_2D_pollution.table) # Load the data
data.db <- db.create(Exdemo_2D_pollution.table,flag.grid=FALSE,ndim=2,
	autoname=F)
data.db

# Visualizing the data set (proportional representation)
plot(data.db,pch=21,bg.in="black",title="Zn Samples location")

# Data Management
data.db <- db.locate(data.db,"Zn","z",1)
data.db <- db.sel(data.db,Zn<20)
print(data.db,flag.stats=TRUE,name="Zn")
print(data.db,flag.stats=TRUE,name="Pb")
data.db <- db.add(data.db,Zn.transformed=Zn+Pb+2)
print(data.db,flag.print=TRUE)

# Calculate experimental omni-directional variogram
data.vario <- vario.calc(data.db,lag=1,nlag=10)
data.vario
plot(data.vario,npairpt=1,npairdw=TRUE,title="Omni-directional variogram")

# Calculate experimental variogram in 4 directions
data.4dir.vario <- vario.calc(data.db,lag=1,nlag=10,dir=c(0,45,90,135))
plot(data.4dir.vario,title="Directional variograms")

# Fitting the omni-directional variogram with an isotropic model (loaded)
data.model <- model.auto(data.vario,struc=c("Spherical","Exponential"),
	   title = "Modelling omni-directional variogram")
data.model

# Creating neighborhood structures
data(Exdemo_2D_unique.neigh) # Load the unique neighborhood
Exdemo_2D_unique.neigh
data(Exdemo_2D_moving.neigh) # Load the moving neighborhood
Exdemo_2D_moving.neigh

# Cross-validation
data.db <- xvalid(data.db,data.model,Exdemo_2D_moving.neigh,modify.target=F)
hist(db.extract(data.db,"Xvalid.Zn.esterr"),nclass=30,main="Histogram of Zn",
	xlab="Cross-validation error",col="blue")

# Create a new grid
grid.db <- db.grid.init(data.db,nodes=c(100,90))

# Estimation with the restricted data set (Unique Neighborhood)
grid.db <- kriging(data.db,grid.db,data.model,Exdemo_2D_unique.neigh,radix="KU.Part")
plot(grid.db,name.image="z1",col=topo.colors(20),
	title="Estimation - Data subset (Unique Neighborhood)")
plot(grid.db,name.contour="z2",nlevels=10,add=TRUE)
plot(data.db,pch=21,bg.in=1,add=TRUE)
plot(grid.db,name.persp="z1",theta=45,phi=30,zlim=c(3,25),
	title="Estimation - Data subset (Unique Neighborhood)")

# Estimation with the whole data set (Unique Neighborhood)
data.db <- db.sel(data.db)
grid.db <- kriging(data.db,grid.db,data.model,Exdemo_2D_unique.neigh,radix="KU.All")
plot(grid.db,name.image="z1",col=topo.colors(20),
	title="Estimation - All data (Unique Neighborhood)")
plot(grid.db,name.contour="z2",nlevels=10,add=TRUE)
plot(data.db,pch=21,bg.in=1,add=TRUE)
plot(grid.db,name.persp="z1",theta=45,phi=30,zlim=c(3,25),
	title="Estimation - All data (Unique Neighborhood)")

# Estimation with the whole data set (Moving Neighborhood)
grid.db <- kriging(data.db,grid.db,data.model,Exdemo_2D_moving.neigh,radix="KM.All")
plot(grid.db,name.image="z1",col=topo.colors(20),
	title="Estimation - All data (Moving Neighborhood)")
plot(grid.db,name.contour="z2",nlevels=10,add=TRUE)
plot(data.db,pch=21,bg.in=1,add=TRUE)
plot(grid.db,name.persp="z1",theta=45,phi=30,zlim=c(3,25),
	title="Estimation - All data (Moving Neighborhood)")

# Checking the Moving Neighborhood
grid.db <- neigh.test(data.db,grid.db,data.model,Exdemo_2D_moving.neigh,radix="Moving")
plot(grid.db,name.image="z1",title="Number of samples")
plot(data.db,pch=21,bg.in=1,add=TRUE)
plot(grid.db,name.image="z2",title="Largest distance data-target")
plot(data.db,pch=21,bg.in=1,add=TRUE)
plot(grid.db,name.image="z3",title="Smallest distance data-target")
plot(data.db,pch=21,bg.in=1,add=TRUE)

# Gaussian Anamorphosis
data.db <- db.sel(data.db,sel=6)
data.anam <- anam.fit(data.db,"Zn")
print(data.anam)
data.db <- anam.z2y(data.db,"Zn",anam=data.anam)
print(data.db,name="Gaussian.Zn")

# Structural analysis of the Gaussian Transformed variable
data.g.vario <- vario.calc(data.db,nlag=10,lag=1)
plot(data.g.vario,npairdw=T,npairpt=T)
data.g.model <- model.auto(data.g.vario,struct=c("Exponential"))

# Conditional simulations
grid.db <- simtub(data.db,grid.db,data.g.model,Exdemo_2D_unique.neigh,
	nbsimu=10,nbtuba=100)
grid.db <- anam.y2z(grid.db,ngrep="Simu.Gaussian.Zn",anam=data.anam)

# Perform statistics on the conditional simulations
grid.db <- db.compare(grid.db,ngrep="Raw.Simu.Gaussian.Zn",fun="mean")
plot(grid.db,zlim=c(3,13),col=topo.colors(20))
plot(data.db,pch=21,bg.in=1,add=TRUE)
grid.db <- db.compare(grid.db,ngrep="Raw.Simu.Gaussian.Zn",fun="stdv")
plot(grid.db,col=topo.colors(20))
plot(data.db,pch=21,bg.in=1,add=TRUE)

# Plot conditional simulations in Raw scale
plot(grid.db,name.image="Raw.Simu.Gaussian.Zn.S1",
	zlim=c(3,13),col=topo.colors(20))
plot(data.db,pch=21,bg.in=1,add=TRUE)
plot(grid.db,name.image="Raw.Simu.Gaussian.Zn.S2",
	zlim=c(3,13),col=topo.colors(20))
plot(data.db,pch=21,bg.in=1,add=TRUE)

# Ending the test
clean()
