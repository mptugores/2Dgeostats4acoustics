# 
# This demonstration provides a demonstration
# for Automatic Structure Fitting
#
clean <- function()
{
	if (get.yn("Clean the data set",default="y"))
	{
		liste <- c("Exdemo_autofit1.model","Exdemo_autofit2.model",
		           "Exdemo_autofit3.vario","Exdemo_autofit4.vario",
			   "Exdemo_autofit5.vario","Exdemo_autofit6.vario",
			   "Exdemo_autofit7.model",
			   "clean")
		for (i in 1:length(liste))
		    if (exists(liste[i])) rm(list=liste[i],pos=1)
		if (dev.cur() != 1) dev.off()
	}
}

########################################
# Case of an isotropic digitized model #
########################################
data(Exdemo_autofit1.model)
vario <- model.sample(Exdemo_autofit1.model,lag=0.1,nlag=100)
plot(vario,title="Isotropic Digitized Model to be Fitted")
model <- model.auto(vario,maxiter=100,
      title="Isotropic Digitized Model")
rm(vario,model,pos=1)

##########################################
# Case of an anisotropic digitized model #
##########################################
data(Exdemo_autofit2.model)
vario <- model.sample(Exdemo_autofit2.model,lag=0.1,nlag=100,
      dirvect=c(0,45,90,135))
plot(vario,title="Anisotropic Digitized Model to be Fitted")
model <- model.auto(vario,maxiter=100,
      title="Anisotropic Digitized Model")
rm(vario,model,pos=1)

######################################################################
# Case of real variogram calculated in 4 directions in the 2-D space #
######################################################################
data(Exdemo_autofit3.vario)
plot(Exdemo_autofit3.vario,
	title="Experimental Variogram in 2-D space to be Fitted")
model <- model.auto(Exdemo_autofit3.vario,maxiter=100,
        title="Experimental variogram in 2-D space")
rm(model,pos=1)

######################################################################
# Case of real variogram calculated in 3 directions in the 3-D space #
######################################################################
data(Exdemo_autofit4.vario)
plot(Exdemo_autofit4.vario,
	title="Experimental Variogram in 3-D space to be Fitted")
model <- model.auto(Exdemo_autofit4.vario,maxiter=100,
        title="Experimental Variogram in 3-D space")
rm(model,pos=1)

#####################
# Multivariate case #
#####################
data(Exdemo_autofit5.vario)
model <- model.auto(Exdemo_autofit5.vario,maxiter=100,draw=FALSE)
# Variables [1,5]
plot(Exdemo_autofit5.vario,varcols=seq(1,5))
plot(model,Exdemo_autofit5.vario,varcols=seq(1,5),add=T)
# Variables [1,5] against [6,10]
plot(Exdemo_autofit5.vario,varcols=seq(1,5),varcols2=seq(6,10))
plot(model,Exdemo_autofit5.vario,varcols=seq(1,5),varcols2=seq(6,10),add=T)
# Variables [1,5] against [11,15]
plot(Exdemo_autofit5.vario,varcols=seq(1,5),varcols2=seq(11,15))
plot(model,Exdemo_autofit5.vario,varcols=seq(1,5),varcols2=seq(11,15),add=T)
# Variables [6,10]
plot(Exdemo_autofit5.vario,varcols=seq(6,10))
plot(model,Exdemo_autofit5.vario,varcols=seq(6,10),add=T)
# Variables [6,10] against [11,15]
plot(Exdemo_autofit5.vario,varcols=seq(6,10),varcols2=seq(11,15))
plot(model,Exdemo_autofit5.vario,varcols=seq(6,10),varcols2=seq(11,15),add=T)
# Variables [11,15]
plot(Exdemo_autofit5.vario,varcols=seq(11,15))
plot(model,Exdemo_autofit5.vario,varcols=seq(11,15),add=T)

rm(model,pos=1)

##########################
# Breaking the ambiguity #
##########################
data(Exdemo_autofit6.vario)
plot(Exdemo_autofit6.vario,
	title="Experimental directional variograms on the grid")
model <- model.auto(Exdemo_autofit6.vario,maxiter=100,
        title="Experimental directional variograms on the grid")
model <- model.auto(Exdemo_autofit6.vario,maxiter=100,
      struct=melem.name(c(3,3,3)),title="Fitting with 3 sphericals")
rm(model,pos=1)

###########################
# Fitting a Variogram map #
###########################
grid <- db.create(flag.grid=T,nx=c(200,200))
data(Exdemo_autofit7.model)
cat("Attention: This (last) part of the case study may be time consuming...")
grid <- simtub(,grid,Exdemo_autofit7.model)
vmap <- vmap.grid(grid,nx=30,ny=30,flag.fft=TRUE)
model <- vmap.auto(vmap,maxiter=100,struct=melem.name(c(1,3,3)))
rm(grid,model,vmap,pos=1)

clean()
