# 
# This demonstration provides a graphic representation
# of the main basic structures available in RGeoS
#
clean <- function()
{
	if (get.yn("Clean the data set",default="y"))
	{
		liste <- c("ndim","nvar","nx","ny","nmax","ntot",
		           "new.page","first.page","vartype","model",
			   "rank","nval","list","nstruct","num.screen",
			   "clean")
		for (i in 1:length(liste))
		    if (exists(liste[i])) rm(list=liste[i],pos=1)
		if (dev.cur() != 1) dev.off()
	}
}

# General constants #
ndim <- 2
nvar <- 1
nx   <- 2
ny   <- 2
nmax <- NA
ntot <- nx * ny

# Close any previous screen #
if (split.screen()[1]) clean.window()

# List of the authorized structures #
list    <- melem.name(degree=0)
nstruct <- length(list)
nval    <- nstruct
if (! miss(nmax)) nval <- min(nmax,nstruct)

# Loop on the authorized structures #
new.page   <- TRUE
first.page <- TRUE
for (rank in 1:nval) {
	if (new.page) {
		if (! first.page) {
			clean.window()
		}
		split.screen(c(nx,ny),erase=TRUE)		
		new.page <- FALSE
		first.page <- FALSE
		num.screen <- 1
	}

	screen(num.screen)		
	num.screen <- num.screen + 1
	if (num.screen > ntot) new.page <- TRUE

	vartype <- list[rank]
	model <- new("model",nvar=nvar,ndim=ndim)
	model[1] <- melem.init(ndim=ndim,nvar=nvar,vartype=vartype)
	plot(model,title=vartype,reset=FALSE)
}

clean()
