#
# This demonstration exhibits the features of RGeoS
# when applied to a 1-D data set
#
clean <- function()
{
	if (get.yn("Clean the data set",default="y"))
	{
		liste <- c("Exdemo_1D_well.table","well.db","well.vario",
		           "Exdemo_1D_well.model",
			   "Exdemo_1D_well.neigh","clean")
		for (i in 1:length(liste))
		    if (exists(liste[i])) rm(list=liste[i],pos=1)
		if (dev.cur() != 1) dev.off()
	}
}

# Load the data set in a grid format
data(Exdemo_1D_well.table)
well.db <- db.create(Exdemo_1D_well.table,flag.grid=TRUE,
	x0=519.00074,dx=0.02002,nx=850,autoname=FALSE)
well.db

# Set the target variable to Conductivity (Rank 4)
well.db <- db.locate(well.db,4,"z",1)
# Delete the field "Depth" (Rank 3) as similar to field 2
well.db <- db.delete(well.db,3)

# Print statistics from the file
print(well.db,flag.stats=TRUE)

# Display the data set
plot(well.db,title="Conductivity information")

# Calculate the experimental (grid) variogram for 500 lags
# Fit a model (loaded)
well.vario <- vario.grid(well.db,nlag=500)
plot(well.vario,"Variogram of Conductivity")

# Model definition (loaded)
data(Exdemo_1D_well.model)
Exdemo_1D_well.model <- model.fit(well.vario,Exdemo_1D_well.model,title="Model of Conductivity")
print(Exdemo_1D_well.model)

# Neighborhood definition (loaded)
data(Exdemo_1D_well.neigh)
print(Exdemo_1D_well.neigh)

# Perform the filtering step
well.db <- krimage(well.db,model=Exdemo_1D_well.model,neigh=Exdemo_1D_well.neigh,cov.extract=1,radix="s1",modify.target=FALSE)
plot(well.db,name.line="s1.Conductivity.estim",title="Component #1")

well.db <- krimage(well.db,model=Exdemo_1D_well.model,neigh=Exdemo_1D_well.neigh,cov.extract=2,radix="s2",modify.target=FALSE)
plot(well.db,name.line="s2.Conductivity.estim",title="Component #2")

well.db <- krimage(well.db,model=Exdemo_1D_well.model,neigh=Exdemo_1D_well.neigh,cov.extract=3,radix="s3",modify.target=FALSE)
plot(well.db,name.line="s3.Conductivity.estim",title="Component #3")

well.db <- krimage(well.db,model=Exdemo_1D_well.model,neigh=Exdemo_1D_well.neigh,cov.extract=4,radix="s4",modify.target=FALSE)
plot(well.db,name.line="s4.Conductivity.estim",title="Component #4")

well.db <- krimage(well.db,model=Exdemo_1D_well.model,neigh=Exdemo_1D_well.neigh,cov.extract=5,radix="s5",modify.target=FALSE)
plot(well.db,name.line="s5.Conductivity.estim",title="Component #5")

well.db <- krimage(well.db,model=Exdemo_1D_well.model,neigh=Exdemo_1D_well.neigh,drift.extract=1,radix="sm",modify.target=FALSE)
plot(well.db,name.line="sm.Conductivity.estim",title="Estimated Mean")
print(well.db)

# Check the quality of the results
well.db <- db.add(well.db,Sum=s1.Conductivity.estim+s2.Conductivity.estim+s3.Conductivity.estim+s4.Conductivity.estim+s5.Conductivity.estim+sm.Conductivity.estim)
plot(db.extract(well.db,"Conductivity"),db.extract(well.db,"Sum"))

# Ending the test
clean()
